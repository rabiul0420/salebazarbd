<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
   
<h2>Welcome to the salebazarbd.com {{$user['name']}}</h2>
<br/>
Your registered email-id is {{$user['email']}} 
</body>

</html>